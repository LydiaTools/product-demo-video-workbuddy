# Product Demo Video with WorkBuddy

[简体中文](README.zh-CN.md) · **English**

**Turn a verified product workflow into a clear, editable promotion video.**

This WorkBuddy Skill helps produce short videos for desktop software, browser extensions, mobile apps, SaaS products, and online services. It starts with the product’s actual category and current evidence, then builds an editable video from real screens, clear copy, stable motion, music, and export checks.

The included BFTiles example shows a Windows desktop utility that arranges and restores window layouts. It is not presented as a cloud service.

## What the Skill does

- Checks product type and supported features against current sources.
- Plans a concise hook, evidence, product result, and CTA before coding.
- Uses real product screenshots or recordings and keeps invented UI clearly illustrative.
- Builds an editable Remotion project with controlled movement, captions, music, and sound effects.
- Exports a short sample before a full video and preserves the approved sample.
- Records asset sources, render settings, and remaining verification limits.

## Install in WorkBuddy

Copy the repository folder into:

    %USERPROFILE%\.workbuddy\skills\product-demo-video-workbuddy

Keep SKILL.md at the top level. Restart or refresh the Skills list only if the current WorkBuddy version requires it.

## What you need

- WorkBuddy with local file and shell access
- Node.js 18 or later
- Python 3
- FFmpeg and FFprobe
- A Remotion-compatible project; the Remotion license is separate from this Skill’s MIT license
- Rights to use each product image, logo, font, soundtrack, and effect

See SKILL.md, the WorkBuddy workflow, stable rendering, and asset and license checks.

## Example

The local BFTiles opening sample uses real, cropped v2.3.5 interface images, a steady landscape composition, and no voiceover. It is an approved opening sample, not the full tutorial. The full sample project and its source notes are stored in the production workspace.

## Source and attribution

Adapted from [noamdorr/saas-product-demo-video](https://github.com/noamdorr/saas-product-demo-video), an MIT-licensed Remotion Skill. The source license is retained in LICENSE.upstream, and the changes are summarized in references/adaptation.md.

This project does not bundle Remotion, FFmpeg, or third-party music. Review their separate terms before commercial use.
