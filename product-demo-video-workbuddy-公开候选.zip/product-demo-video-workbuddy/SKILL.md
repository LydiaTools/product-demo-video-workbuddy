---
name: product-demo-video-workbuddy
description: Create clear software product promotion videos with WorkBuddy, Remotion, real product screens, stable motion, music, and checked exports.
license: MIT
compatibility: WorkBuddy with local filesystem and shell access; Node.js 18+, Python 3, and FFmpeg are needed for the included Remotion workflow.
---

# Product Demo Video with WorkBuddy

Use this Skill when a user wants to make or revise a short product promotion video for desktop software, browser extensions, mobile apps, SaaS products, or online services. It turns verified product information, real UI assets, and a clear customer problem into an editable Remotion project and MP4.

## Product classification comes first

Before writing copy, verify the product type from its current official product page or installed interface. Say "desktop software," "browser extension," "SaaS," or another type only when the evidence supports it. Do not call every software product SaaS. For example, BFTiles is a Windows desktop window-layout utility; this example does not describe a cloud service.

Keep product claims tied to the official source or a real product screen. Do not invent ratings, customers, performance percentages, sales outcomes, subscriptions, compatibility, or features. Distinguish product behavior from the video-making workflow.

## Workflow

1. **Read the product brief and current sources.** Record the product type, audience, problem, supported features, required assets, aspect ratio, duration, CTA, and license status. Use current official pages and user-provided materials; list anything that remains unverified.
2. **Plan the story before editing.** Write a short brief and storyboard with one clear claim, a problem hook, product evidence, a result, and a simple CTA. Match on-screen labels to real interface terminology.
3. **Use actual product material.** Prefer the real product UI or screen recording. Crop only to remove irrelevant surroundings or sensitive values. If a product has no recordable UI, use clearly illustrative shapes; do not pass an invented screen off as a real product interface.
4. **Build the video.** Use the supplied Remotion scaffold or the existing project. Keep the composition data-driven, use actual product branding, purposeful scene changes, and picture-locked sound. Use a stable camera by default: do not add global shake, oscillation, subpixel drift, or repeated zooms. Animate selected objects or labels independently while product screenshots remain sharp and steady.
5. **Render an effect sample first.** Render a short opening or representative sample, inspect it, and send it to the user. Continue to the full video after the user approves the direction. Preserve the approved sample as an asset; do not describe it as the complete tutorial.
6. **Render the full export.** Default to 16:9 landscape at 1920×1080 and 30 fps unless the user asks for another format. Tag color as BT.709, preserve the selected soundtrack and approved voiceover, and save the MP4 plus editable project and source notes.
7. **Check what was actually made.** Render stills from the opening, middle, and ending. Check text, spacing, scene continuity, picture stability, UI accuracy, soundtrack and effects, and the final export metadata. A technical check is not a claim of user approval. Do not run a mobile-size check unless the user asks for one.

## WorkBuddy execution

When running this Skill through WorkBuddy:

- Keep the Skill directory and project assets in the user's local workspace. The normal WorkBuddy Skills folder on Windows is %USERPROFILE%\.workbuddy\skills\product-demo-video-workbuddy; confirm the actual configured path before installing.
- Work from a copy of any approved project. Never overwrite an accepted sample or a prior final file.
- In the prompt, name the exact product type, source files, output folder, aspect ratio, runtime, soundtrack, and claims to avoid.
- Read the Skill and the product brief before editing. Show the user the actual WorkBuddy prompt, model response, file changes, render command, and resulting artifact.
- Do not say WorkBuddy produced or rendered an output unless the WorkBuddy task actually ran and the resulting file exists.
- If a service requires login, a new software install, a paid API, a purchase, or a private credential, stop at that step and report the dependency; do not fabricate access.

## Audio and copy

Music and sound effects should support the real action without overpowering narration. Keep voiceover, music, and effects on separate tracks until the final mix. Use the user's approved voice workflow when one exists. Do not add unapproved spoken lines, laughter, or processing to an approved track.

## License and delivery

This Skill adapts the MIT-licensed noamdorr/saas-product-demo-video project. Keep LICENSE.upstream and the attribution in references/adaptation.md with redistributions. Remotion has its own separate license; verify the applicable terms for the organization before commercial deployment. Check music, fonts, logos, screenshots, and product marks separately. Do not imply that the Skill's MIT license covers those assets.

Return the product type, evidence sources, output path, editable project path, quality checks performed, and any remaining limitations. Keep production-source notes in the handoff documents; do not add production-status labels to the video.
