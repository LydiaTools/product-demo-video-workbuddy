# Stable rendering

- Keep the camera and large product screenshots fixed unless a specific move helps explain the product.
- Avoid global camera shake, oscillating transforms, fractional pixel drift, frequent zooms, and animated raster scaling.
- Prefer opacity reveals, integer-pixel translation, and independent vector callouts.
- Use source images at or above their on-screen dimensions. Do not enlarge small screenshots and expect text to stay sharp.
- Make transitions serve a visible change; do not use motion to hide a missing product response.
- Align each effect with its visible event and mix it below narration.
- Inspect one still from every scene and play the rendered MP4 continuously before delivery.
