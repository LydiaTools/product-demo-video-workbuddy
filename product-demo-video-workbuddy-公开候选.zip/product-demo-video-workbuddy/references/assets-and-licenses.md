# Product category, sources, and asset licenses

## Product category

Verify the category from the current official page and installed interface:

- Desktop application: installed and launched on an operating system
- Browser extension: installed in a browser, with its actual extension UI
- SaaS: hosted cloud service accessed through a browser or app
- Mobile application: installed on a phone or supported emulator
- Other: use the wording the product owner uses and document the evidence

Do not infer SaaS from the fact that a product uses AI or requires an account.

## Claim evidence

Record each spoken or on-screen claim with its supporting URL or source file. Use only current, specific evidence. Leave unsupported claims out of the script.

## Assets

Keep screenshots, recordings, logos, typography, music, and effects local to the project. Track their source and permission separately. The MIT license in this repository does not cover external assets or Remotion.
