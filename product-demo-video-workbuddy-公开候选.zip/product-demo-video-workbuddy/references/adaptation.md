# Adaptation record

Upstream project: https://github.com/noamdorr/saas-product-demo-video
Upstream Skill: https://github.com/noamdorr/saas-product-demo-video/tree/main/skills/saas-product-demo-video
License: MIT, retained in LICENSE.upstream.

This WorkBuddy adaptation:

- Renames the Skill to a generic product-demo video name.
- Explicitly distinguishes desktop software, browser extensions, SaaS, and mobile apps.
- Adds a WorkBuddy-first local workflow and installation path.
- Adds stable-camera and raster-sharpness rules based on observed sample problems.
- Requires a real short sample before the full video and keeps the sample separate from the completed tutorial.
- Adds BFTiles as a verified desktop-software example without describing it as SaaS.
- Retains upstream references and helper scripts; product assets and third-party dependencies keep their own licenses.
