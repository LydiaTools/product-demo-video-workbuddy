# WorkBuddy workflow

## 1. Intake

Create docs/video/brief.md with:

- Product category and current evidence
- Intended audience and the problem they recognize
- One verified product feature to demonstrate
- Output aspect ratio, duration, language, voice, music, and CTA
- Asset list with source, capture date, crop, and permission notes
- Claims that the current evidence does not support

For BFTiles, use "Windows desktop software" and demonstrate window layout rules and restore controls. Do not describe it as SaaS or imply cloud synchronization.

## 2. Script and storyboard

Use a compact sequence:

1. A concrete user problem
2. A real product screen or action
3. The product response
4. A second verified action or outcome
5. Product name and useful next step

For a screen-based tutorial, preserve action order and visible cause and effect. A cut may shorten waiting but must not make an action appear before its trigger.

## 3. WorkBuddy task

The WorkBuddy prompt should name:

- The exact Skill folder and product brief
- The exact screenshot or recording assets
- The output folder
- The selected format and runtime
- Required audio and claims to avoid
- A request for editable source, MP4, and a short run report

Ask WorkBuddy to read the Skill and sources first. Do not put passwords, tokens, or private account data in the task prompt.

## 4. Render and review

Render the short opening first. Preserve that approved render in a separate file. After approval, build the complete video from a copy of the project. Save the render command and output hash in docs/video/delivery.md.
