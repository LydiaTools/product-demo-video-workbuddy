# WorkBuddy 软件产品推广视频 Skill

[English README](README.md)

**把经过核实的软件功能与真实界面，做成清晰、可编辑的推广视频。**

这个 Skill 支持 Windows 桌面软件、浏览器插件、手机应用、SaaS 和在线服务。它会先按官方资料判断产品类型，再设计口播与分镜，用真实界面、稳定动效、配乐和音效制作 Remotion 工程与成片。

BFTiles 案例是 Windows 桌面窗口布局工具，不是云服务。示例截图来自实际产品界面，开头样片已获确认；它还不是完整教程视频。

## 适用流程

- 先核实产品类型、功能、素材来源和授权。
- 先写分镜：用户问题、产品证据、可见结果、行动提示。
- 使用真实界面截图或完整录屏；不把自绘界面伪装成软件实况。
- 画面默认锁定稳定机位，不加全屏抖动、亚像素漂移或反复缩放。
- 先出短样，用户认可后再继续成片。
- 交付 MP4、可编辑工程、素材来源与检查记录。

## 安装

将仓库文件夹复制到：

    %USERPROFILE%\.workbuddy\skills\product-demo-video-workbuddy

确认 SKILL.md 位于文件夹顶层；如果当前 WorkBuddy 版本需要刷新 Skill 列表，再按实际界面刷新。

## 环境

- WorkBuddy 本地文件与命令行能力
- Node.js 18+
- Python 3
- FFmpeg / FFprobe
- Remotion 工程（Remotion 有单独的授权条件）
- 每个产品界面、商标、字体、音乐和音效都需要单独确认使用权

安装与制作步骤见 WorkBuddy 工作流、稳定画面指南和素材授权指南。

## 上游与改造

本项目适配自 MIT 开源仓库 [noamdorr/saas-product-demo-video](https://github.com/noamdorr/saas-product-demo-video)，保留原许可于 LICENSE.upstream。具体改动见 references/adaptation.md。

本仓库不捆绑 Remotion、FFmpeg 或第三方音乐。商业使用前需分别核对各组件的授权条件。
